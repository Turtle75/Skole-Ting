package opgave5_1;

import java.util.Scanner;

public class Opgave5_1 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        //Variablerne erklæres
        int valg;
            HelloThere();
            valg = scanner.nextInt();

            while (valg == 1){
                HelloThere();
                valg = scanner.nextInt();
            }
    }//Main slut

    public static void HelloThere(){
        int count = 10, tal, valg;
        Scanner scanner = new Scanner(System.in);
        //Vælger et tilfældigt heltal fra 1 til 100
        tal = (int)(Math.random()*100);

        System.out.println("Opgave 5.1");
        //Introduktion til bruger
        System.out.println("Gaet et heltal fra 0 til 100");

        //Læser hvad brugeren skriver
        int brugergaet = scanner.nextInt();

        //Imens betingelsen er forkert, eksekvere den foelgende kode (Samtidig med at antallet af gæt er under 10)
        while ((brugergaet != tal)&&(count <= 10)){
            //Tæller et forsøg ned pr. gaet
            count -= 1;

            //Tjekker om vaerdien er for høj eller for lav
            if (brugergaet > tal){
                System.out.println("Dit gaet er for hoejt");
            }
            else {
                System.out.println("Du har gaettet for lavt");
            }

            //Nogle notifikationer så brugeren loebende ved hvor mange gaet der er tilbage
            if (count == 5){
                System.out.println("\nDu har 5 gaet tilbage!");
            }
            else if (count == 1){
                System.out.println("\nDu er paa dit sidste gaet, held og lykke");
            }
            //Hvis der ikke er flere forsoeg tilbage, saa gaar den ud af while-loekken med break
            else if (count == 0){
                break;
            }

            brugergaet = scanner.nextInt();
        }
        //While-loekke slut

        //Hvis tallet brugergaet er lig med tallet
        if (brugergaet == tal)
        {
            System.out.println("Det er det rigtige svar");

        }
        //Ellers er man loebet toer for gaet
        else
        {
            System.out.println("Du er loebet toer for gaet, held og lykke naeste gang");
        }
        System.out.println("Vil du spille igen? Tryk paa 1 for at spille igen");
    }
}//Class slut
