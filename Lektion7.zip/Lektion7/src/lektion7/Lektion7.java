package lektion7;

import java.util.Scanner;

public class Lektion7 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        //Introduktion til bruger
        System.out.println("Indtast hvilken opgave der skal vises.");
        System.out.println("For at vise eksempel 1 fra lektionssaettet tryk paa 1 og ENTER. For at vise opgave 1, saa indtast 2 og ENTER");

        //Opretter scanner til brugerinput
        int tal = scanner.nextInt();

        //Hvis tallet brugeren har inputtet er 1, saa koerer den program1
        if (tal == 1){
            Lektion7Program1.HelloThere();
        }
        //Hvis tallet brugeren har inputtet er 2, saa koerer den opgave1
        if (tal == 2){
            Lektion7Opgave1.HelloThere();
        }
    }
}
