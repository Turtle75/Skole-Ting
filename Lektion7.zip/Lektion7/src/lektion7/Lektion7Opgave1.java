package lektion7;

import java.util.Scanner;

public class Lektion7Opgave1 {
    public static void HelloThere(){
        //Introduktion til bruger
        System.out.println("Indtast din alder, saa beregnes dit foedselsaar");
        //Erklaering af variabler
        int tal1 = 0;
        double tal2 = 0;

        //Kalder foerst metoden anInt() og printer derefter tekststykket samt vaerdien ud
        System.out.println("Dit foedselsaarstal er: " + anInt(tal1) + "\n");
        //Kalder foerst metoden aDouble() og printer derefter tekststykket samt vaerdien ud
        System.out.println("Kvadratroden af dit tal er: " + aDouble() + "\n");
        //Kalder metoden ord, som er en String-metode
        System.out.println(ord());
    }

    //Int metoden
    public static int anInt(int tal1){
        //Variablerne erklaeres
        int aarstal = 2022;
        Scanner scanner = new Scanner(System.in);
        tal1 = scanner.nextInt();

        //Erklaerer variabler
        tal1 = aarstal-tal1;
        return tal1;
    }
    //Double metoden
    public static double aDouble(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Indtast et tal, som der skal tages kvadratroden af");
        double tal2 = scanner.nextDouble();

        //Kvadratroden af tal2 beregnes
        tal2 = Math.sqrt(tal2);

        return tal2;
    }
    //String metoden
    public static String ord(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Indtast dit kodeord: ");

        //Variablerne erklaeres
        int forsoeg = 9;
        String korrekt = "You have done well, lord Vader";

        //saetter den naeste linje brugeren skriver til at vaere Stringen password
        String password = scanner.nextLine();

        //While-loekke til at se om brugeren skriver den rigtige kode ind
        while (!password.equals("Hello There")){
            if (forsoeg == 9){
                System.out.println("Det er dig... ikke? Du skrev maaske bare forkert");
            }
            System.out.println("Du har " + forsoeg + " foersoeg tilbage");

            //Forsoeg gaar en ned, hver gang koden koerer
            forsoeg -= 1;

            //Goer saa brugeren kan indtaste igen
            password = scanner.nextLine();

            if (forsoeg == 0){
                //Hvis brugeren er loebet toer for forsoeg hopper den ud af while-loekken
                break;
            }
        }
        //While-loekke slut

        if (forsoeg == 0 && !password.equals("Hello There")){
            String forkert = "You are expelled from the Jedi Order";

            //Hvis der ikke er flere foersoeg tilbage saa returnere den Stringen forkert, som er defineret herover
            return forkert;
        }
        else
        {
            System.out.println("General Kenobi");

            //Hvis der er det rigtige svar, saa returnere den Stringen korrekt, som blev defineret oeverst i metoden
            return korrekt;
        }
    }
}