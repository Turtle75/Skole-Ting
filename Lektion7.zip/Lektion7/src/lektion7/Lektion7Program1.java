package lektion7;

import java.util.Scanner;

public class Lektion7Program1
{
    public static void HelloThere()
    {
        //opretter scanner til brugerinput
        Scanner scanner = new Scanner(System.in);
        //Variablerne erlaeres
        int inddata, faktor = 4, uddata;

        System.out.println("Indtast et tal, der skal krypteres: ");

        //Scanner naeste input, og indsaetter i variablen inddata
        inddata = scanner.nextInt();

        //Kalder metoden krypter, som er en static int
         uddata = krypter(faktor,inddata);
         //Printer det krypterede tal ud
        System.out.println("Det kryperede tal er: " + uddata);
    }

    //Int metoden
    public static int krypter(int faktor, int tal){
        int ud = tal*faktor+5;
        return ud;
    }
}
