package lektion6;

public class Opgave2 {
    public static void HelloThere(){
        System.out.println("Opgave 6.2");
        System.out.println("1+2+3+4+5... 20+=?");
        System.out.println("\n Beregner \n");
        //Variablerne erklæres
        int tal = 0;
        int sum = 0;

        for (tal=1;tal<=20;tal++){
            sum = sum + tal;
        }
        System.out.print("1+2+3+4+5... 20+= "+sum);
    }
}
