package lektion6;

public class Opgave4 {
    public static void HelloThere(){
        System.out.println("Opgave 6.4 del 1");
        //Variablerne erlaeres
        int n, ligning = 0;


        for (n = 0; n<=10; n++)
        {
            System.out.println("Loeser nu f(" + n + ")");

            ligning = 3*n*n+6*n+9;

            System.out.println(" = "+ligning);
        }
    }
}
