package lektion6;

import java.util.Scanner;

public class Lektion6 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Vaelg opgave 1 forklaring eller opgave 1-4, ved at indtaste 0, 1, 2, 3 eller 4 og enter");
        System.out.println("Hvis du vil vaelge ekstraopgaverne til opgave 3, eller del 2 af opgave 4, skriv 5 eller 6");

        int valgOpgave = scanner.nextInt();

        if (valgOpgave == 0){
            ForklaringEksempler.HelloThere();
        }
        else if (valgOpgave == 1){
            Opgave1.HelloThere();
        }
        else if (valgOpgave == 2){
            Opgave2.HelloThere();
        }
        else if (valgOpgave == 3){
            Opgave3.HelloThere();
        }
        else if (valgOpgave == 4){
            Opgave4.HelloThere();
        }
        else if (valgOpgave == 5){
            Opgave3Brugerdefineret.HelloThere();
        }
        else if (valgOpgave == 6){
            Opgave4Del2.HelloThere();
        }
        else
        {
            System.out.println("Det er ikke et gyldigt input, koer koden igen");
        }
    }
}