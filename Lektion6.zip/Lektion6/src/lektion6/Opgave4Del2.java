package lektion6;

public class Opgave4Del2 {
    public static void HelloThere() {
        System.out.println("Opgave 6.4 del 2");
        int n, ligning = 0;


        for (n = 0; n <= 100; n += 10) {
            ligning = (int) (3 * Math.pow(n, 2) + 6 * n + 9);

            System.out.println("Loeser nu f(" + n + ")");
            System.out.println(" = " + ligning);
        }
    }
}
