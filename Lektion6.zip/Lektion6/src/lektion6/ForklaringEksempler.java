package lektion6;

public class ForklaringEksempler {
    public static void HelloThere(){
        /*
        int n;
        for (n=1;n<=10;n=n+1){
            //Ganger variablen n med 7
            System.out.println(n+" : " + 7*n);
        }
         */

        /*
        int n;
        for (n=1;n<=10;n++)
        {
            //Tjekker om variablen n er 6, og hvis ja, så outputter den System.out
            if (n == 6) System.out.println("Puha, det bliver svaert.");

            //Indtil variablen n er 8, så beregner den på normal vis
            if (n<8) System.out.println(n+" : "+7*n);
                //Hvis n er højre end 8, så siger den ved ikke
            else System.out.println(n+" : (ved ikke)");
        }
        */

        int sum = 0,n = 0;

        //Imens n er 10...
        for (n=1;n<=10;n++){
            //Skriver nummeret på variablen n, samt outputter summen
            System.out.print(" "+n+" : "+sum);

            int toer = 0;

            //Imens j er mindre end 4 skal den kører denne kode
            for (int j=0;j<4;j++){
                //Skriver bare plus 2 (4 gange da lykken kører 4 gange)
                System.out.print("+2");
                //Beregner summen af 2*4 (Da lykken kører 4 gange
                toer = toer + 2;
            }
            //Efter 4 gange siger den så at summen svarer til summen plusset med resultatet af toer ovenover som altid vil være 8
            sum = sum + toer;
            //Printer til sidst summen ud
            System.out.println(" = "+sum);
        }
    }
}
