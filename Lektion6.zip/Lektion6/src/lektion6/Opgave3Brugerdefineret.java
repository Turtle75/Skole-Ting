package lektion6;

import java.util.Scanner;

public class Opgave3Brugerdefineret {

    public static void HelloThere(){
        System.out.println("Opgave 6.3 med brugerdefineret tabel\n");

        //Erklære variabler
        int tal, n = 0, sum = 0;
        //Scanner til brugerens input
        Scanner scanner = new Scanner(System.in);

        System.out.println("Indtast tabel fra 1 til 10");

        //Laver lykken til den brugerdefineret vaerdi
        for (tal=scanner.nextInt();n<10;n++)
        {
            //Summen erklæres
            sum = sum + tal;
            //Printer de individuelle dele af tabellen ud
            System.out.println(tal + " : "+ sum);

            //Hvis tallet er over 10, gaar den ud af loekken
            if (tal > 10)
            {
                break;
            }

        }
        //Hvis tal er over 10, saa siger den at den ikke kan finde ud af det
        if (tal > 10)
        {
            System.out.println("Det kan jeg ikke finde ud af");
        }
        //Ellers siger den faerdig
        else
        {
            System.out.println("Done!");
        }
    }
}
