package lektion6;

public class Opgave1 {
    public static void HelloThere(){
        int n;
        System.out.println("Opgave 6.1\n");
        for (n=15;n<18;n++){
            System.out.println("Du er "+ n + " aar gammel. vent til du bliver aeldre.");
            System.out.println("Tillykke med foedselsdagen!");
        }
        System.out.println("Nu er du " + n + " aar, og myndig");
    }
}
