package lektion6;

public class Opgave3 {
    public static void HelloThere(){
        System.out.println("Opgave 6.3");

        //Variablerne erklaeres
        int n, tabel = 0,j;

        //Loekke til tabellen
        for (n=1;n<=10;n++)
        {
            //Skriver vaerdien af n, som bliver en større hver gang programmet køres
            System.out.print(" "+n + "-tabellen");

            //Starter altid med at sige 0
            System.out.print(": 0");

            //Laver en ny løkke der beregner de individuelle tabeller
            for (j = 1; j<=10;j++)
            {
                //Erklære tabellen og beregner den
                tabel =  tabel+n;
                System.out.print(" : "+ tabel);
            }
            //Resetter tabellen til den naeste tabel.
            tabel = 0;
            //Laver bare en linje til at gøre klar til den næste tabel
            System.out.println();
        }
        //Naar den er faerdig siger den at den ikke gider mere
        System.out.println("Så gider jeg heller ikke mere!");
    }
}
