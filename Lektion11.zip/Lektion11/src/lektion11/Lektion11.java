package lektion11;

public class Lektion11 {
    public static void main(String[] args){
        final int NUM_THROWS = 1000;
        int sum_1 = 0, sum_2 = 0, sum_3 = 0, sum_4 = 0, sum_5 = 0, sum_6 = 0;
        System.out.println("Om lidt laves en terning");
        Terning1 terning = new Terning1();

        for (int count = 1; count <= NUM_THROWS; count++){
            terning.flip();

            if (terning.getFace() == terning.oeje1){
                sum_1++;
            }

            else if (terning.getFace() == terning.oeje2){
                sum_2++;
            }
            else if (terning.getFace() == terning.oeje3){
                sum_3++;
            }
            else if (terning.getFace() == terning.oeje4){
                sum_4++;
            }
            else if (terning.getFace() == terning.oeje5){
                sum_5++;
            }
            else
                sum_6++;
        }
        System.out.println("Der har været 1: " + sum_1);
        System.out.println("Der har været 2: " + sum_2);
        System.out.println("Der har været 3: " + sum_3);
        System.out.println("Der har været 4: " + sum_4);
        System.out.println("Der har været 5: " + sum_5);
        System.out.println("Der har været 6: " + sum_6);
    }
}