package lektion11;

import java.util.Scanner;
public class Terning1 {
    private String farve = "hvid";
    Scanner scanner = new Scanner(System.in);
    public final int oeje1 = 1, oeje2 = 2, oeje3 = 3, oeje4 = 4, oeje5 = 5, oeje6 = 6;
    private int n_kanter = 6, gaet;
    public Terning1(){
        System.out.println("Nu er jeg lavet");
        System.out.println("Proev at gaette, hvad den slaar foerst");
        gaet = scanner.nextInt();
        flip();
        if (gaet == oejne){
            System.out.println("Du gaettede rigtigt");
        }
        else
            System.out.println("Skill issue");
    }
    private int oejne;
    public void flip()
    {    //  Kaster m�nten ved at v�lge siden tilf�ldigt.
        oejne = 1 + (int) (Math.random() * n_kanter);
    }
    public int getFace()
    {  //  Returnerer den side der vender op i form af et heltal.
        return oejne;
    }
}