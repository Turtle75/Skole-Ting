//package mitfoersteprojekt;
//********************************************************************
// Oprindelige forfattere: Lewis and Loftus    Modereret af: Jette Levison
//  Repr�senterer en m�nt med to sider og som kan kastes. 
//********************************************************************
package lektion10;

public class MoentMetal
{

  public final int KRONE = 0;
  public final int PLAT = 1;
  private int face;
  private String metal = "blik";

  public MoentMetal()
  {    //** Konstrukt�r der danner en (blik)m�nt som straks kastes  ***
    flip();
    System.out.println("  test:MetalMoent(): Hej!" + this);
  }

  public MoentMetal(String materiale)
  {   //** Konstrukt�r der danner en m�nt af �nsket metal som straks kastes ***
    metal = materiale;
    flip();
    System.out.println("  test:MetalMoent(" + metal + "): Hej!" + this);
  }

  public void flip()
  {  //** Herfra som f�r*** Kaster m�nten ved at v�lge siden tilf�ldigt ***
    face = (int) (Math.random() * 2);
  }

  public int getFace()
  {  //**  Returnerer den side der vender op i form af et heltal  ***
    return face;
  }

  public String toString()
  {   //**  Returnerer den g�ldende side i form af en tekststreng ***
    String faceName, txt;
    if (face == KRONE)
    {
      faceName = "krone";
    } 
    else
    {
      faceName = "plat";
    }
    txt = "Jeg er en " + metal + "-m�nt og viser " + faceName;
    return txt;
  }
}
