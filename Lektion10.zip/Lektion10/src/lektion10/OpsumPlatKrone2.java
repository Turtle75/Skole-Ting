//package mitfoersteprojekt;
//********************************************************************
//  OpsumPlatKrone.java       Oprindelige forfattere: Lewis and Loftus
//                            Modereret af: Jette Levison
//  Demonstrerer brugen af programm�r-defineret klasse.
//********************************************************************
package lektion10;

public class OpsumPlatKrone2
{
  //-----------------------------------------------------------------
  //  Kaster en m�nt adskillige gange og t�ller antallet af krone- og
  //  platsider.
  //-----------------------------------------------------------------

  public static void main(String[] args)
  {
    final int NUM_FLIPS = 1000;
    int sum_krone = 0, sum_plat = 0;
    System.out.println("\ntest: Main-program: Om lidt laves to m�nter");
    MoentMetal minMoent = new MoentMetal("guld");  // instantierer Moent-objektet
    MoentMetal reserveMoent = new MoentMetal();
    for (int count = 1; count <= NUM_FLIPS; count++)
    {
      minMoent.flip();

      if (minMoent.getFace() == minMoent.KRONE)
      {
        sum_krone++;
      } 
      else
      {
        sum_plat++;
      }
    }
    System.out.println("\nAntal af kast var: " + NUM_FLIPS + ". Fordelt ");
    System.out.println("\tantallet af kroner var: " + sum_krone);
    System.out.println("\tantallet af plat var: " + sum_plat + "\n");
    System.out.println("minMoent siger: " + minMoent
            + " -jeg er helt rundtosset...");
    System.out.println("reserveMoent siger: " + reserveMoent
            + " -stadigv�k, da jeg jo blev liggende");
  }
}
