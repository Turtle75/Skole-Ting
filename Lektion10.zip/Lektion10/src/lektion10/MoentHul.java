package lektion10;

import java.util.Scanner;

public class MoentHul {
    private boolean hul = false;
    public int ja = 1, nej = 0, gaet = 0;
    Scanner scanner = new Scanner(System.in);

    public MoentHul() {
        hulFlip();
        System.out.println("Gaet om den foerste moent har et hul eller ikke (tryk henholdsvis 1 eller 2 og ENTER)");
        gaet = scanner.nextInt();
        if (hul && gaet == 1){
            System.out.println("Du gaettede rigtigt i at der var et hul");
        }
        else if (!hul && gaet == 2){
            System.out.println("Du gaettede rigtigt i at der ikke var et hul");
        }
        else
            System.out.println("Du gaettede forkert");

        if (hul){
            System.out.println("Jeg har et hul lige nu");
        }
        else if (!hul){
            System.out.println("Jeg har ikke et hul lige nu");
        }

    }

    public boolean getHul(){
        return hul;
    }
    public boolean hulFlip(){
        double valg = (int) (Math.random()*2);

        if (valg == 0){
            return hul = false;
        }
        else
            return hul = true;
    }

}
