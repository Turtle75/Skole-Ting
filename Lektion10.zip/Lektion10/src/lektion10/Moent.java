//package mitfoersteprojekt;
//********************************************************************
//  Moent.java       Forfattere: Lewis and Loftus  tilrettet af Jette Levison
//  Repr�senterer en m�nt med to sider og som kan kastes.
//********************************************************************
package lektion10;

public class Moent 
{
  public final int KRONE = 0;
  public final int PLAT = 1;
  private int face;
  //-----------------------------------------------------------------

  public Moent()
  { //  Konstrukt�r der danner en m�nt som straks kastes.
    System.out.println("   test: Moent: Hej, jeg er en ny m�nt. Nu kaster jeg mig lige, s� jeg er klar...");
    flip();
    System.out.println("   test: Moent: " + this);
  }
  //-----------------------------------------------------------------

  public void flip()
  {    //  Kaster m�nten ved at v�lge siden tilf�ldigt.
    face = (int) (Math.random() * 2);
  }

  //-----------------------------------------------------------------
  public int getFace()
  {  //  Returnerer den side der vender op i form af et heltal.
    return face;
  }
  //-----------------------------------------------------------------

  public String toString()
  {  //  Returnerer den g�ldende side i form af en tekststreng.
    String faceName, txt;
    if (face == KRONE)
    {
      faceName = "krone";
    } 
    else
    {
      faceName = "plat";
    }
    txt = "Jeg er en m�nt og viser lige nu " + faceName;
    return txt;
  }
  //-----------------------------------------------------------------
}
