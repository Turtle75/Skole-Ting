//package mitfoersteprojekt;
//********************************************************************
//  OpsumPlatKrone.java       Oprindelige forfattere: Lewis and Loftus
//                            Modereret af: Jette Levison
//  Demonstrerer brugen af programm�r-defineret klasse. 
//********************************************************************
package lektion10;

public class OpsumPlatKrone
{
  //-----------------------------------------------------------------
  //  Kaster en m�nt adskillige gange og t�ller antallet af krone- og
  //  platsider.
  //-----------------------------------------------------------------

  public static void main(String[] args)
  {
    final int NUM_FLIPS = 1000;
    int sum_krone = 0, sum_plat = 0, antal_Hul = 0, antalIkkeHul = 0;
    System.out.println("\ntest: Main-program: Om lidt laves en m�nt");
    Moent minMoent = new Moent();  // instantierer Moent-objektet
    System.out.println("test: Main-program: ok, nu skal vi kaste m�nten "
            + NUM_FLIPS + " gange.");
    MoentHul hulCheck = new MoentHul();

    for (int count = 1; count <= NUM_FLIPS; count++)
    {
      minMoent.flip();
      hulCheck.hulFlip();
      if (hulCheck.getHul()){
        antal_Hul++;
      }
      else
        antalIkkeHul++;


      if (minMoent.getFace() == minMoent.KRONE)
      {
        sum_krone++;
      } 
      else
      {
        sum_plat++;
      }
    }
    System.out.println("\nAntal af kast var: " + NUM_FLIPS + ". Fordelt s�ledes");
    System.out.println("\tantallet af kroner var: " + sum_krone);
    System.out.println("\tantallet af plat var: " + sum_plat + "\n");
    System.out.println("Antallet af hul og ikke-hul var " + NUM_FLIPS + "Fordelt saeledes");
    System.out.println("Antallet af mønter med huller er: " + antal_Hul);
    System.out.println("Antallet af mønter uden huller er: " + antalIkkeHul);
  }
}
