public class ProjektArrays {
    public static void main(String[] args) {
        int[] talListe = new int[96];
        int tal = 0;

        for (int n = 0; n<= 1000;n++){
            tal = (int) ((Math.random() * 105)+1);
            System.out.println(tal + " ");

            if (tal == 0){
                System.out.println("oooof");
            }
        }

    }
}