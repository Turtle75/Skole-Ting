import java.util.Arrays;
import java.util.Collection;

public class ProjektArrays {
    public static void main(String[] args) {
        int[] talListe = new int[95];
        int tal = 0, h = 0;
        double middelvaerdi = 0, sum = 0, standardafvigelse = 0;

        for (int n = 0; n < 95; n++) {
            tal = (int) ((Math.random() * 105) + 1);
            if (tal % 2 == 0) {
                n--;
            } else {
                talListe[n] = tal;
                if (n % 10 == 0){
                    System.out.println();
                }
                System.out.printf("%3d ", talListe[n]);
                h++;
            }
        }
        Sorter(talListe);

        System.out.println("\n\nArrayet bliver sorteret...");
        for (int n = 0; n < talListe.length; n++){
            if (n % 10 == 0){
                System.out.println();
            }
            System.out.printf("%3d ", talListe[n]);
            //System.out.print(talListe[n] + " ; ");
        }
        System.out.println("\nDen hoejeste vaerdi er: " + talListe[1]);
        System.out.println("Den laveste vaerdi er: " + talListe[94]);

        //Beregning af middelvaerdi
        for (int n = 0; n < talListe.length;n++){
            sum = sum + talListe[n];
        }
        System.out.println("Summen af tallene er " + sum);

        middelvaerdi = Middelvaerdi(talListe, sum);
        System.out.println("Middelvaerdien er: " + middelvaerdi);

        standardafvigelse = Standardafvigelse(talListe, middelvaerdi);

        System.out.println(standardafvigelse);

    }
        public static void Sorter(int[] talListe){
            for (int i = 0; i < talListe.length - 1; i++){
                for (int j = i + 1; j < talListe.length; j++){
                    if (talListe[i] < talListe[j]){
                        int temp = talListe[i];
                        talListe[i] = talListe[j];
                        talListe[j] = temp;
                    }
                }
            }
        }
        public static double Middelvaerdi(int[] array, double sum){
                double middelvaerdi;
                middelvaerdi = sum/array.length;
                return  middelvaerdi;
        }

        public static double Standardafvigelse(int[] array, double middelvaerdi){
            double del1 = 0, del2 = 0, del3 = 0;

            for (int n = 0; n < array.length; n++){
                del1 = del1 + Math.pow((array[n] - middelvaerdi), 2);
            }
            del2 = del1/(array.length-1);

            del3 = Math.sqrt(del2);

            return del3;
        }
}