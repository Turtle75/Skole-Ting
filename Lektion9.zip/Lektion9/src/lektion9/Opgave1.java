package lektion9;

public class Opgave1 {
    public static void HelloThere(){
        System.out.println("Fradrag pr. dag fra 25 til 75 km paa hver sin linje");
        int tal = 0;
        double fradrag = 0, pris;
        for (tal = 10; tal <= 150;tal = tal+10){
            if (tal >= 0 && tal <= 24){
                fradrag = 0;
                pris = fradrag * 0.75;
                System.out.println("Naar du koerer " + tal + " km, er fradraget " + fradrag + " og prisen efter skat er " + pris);
            }
            else if (tal > 25 && tal <= 120){
                fradrag = 2.16;
                pris = fradrag * 0.75;
                System.out.println("Naar du koerer " + tal + " km, er fradraget " + fradrag + " og prisen efter skat er " + pris);
            }
            else if (tal > 120){
                fradrag = 1.08;
                pris = fradrag * 0.75;
                System.out.println("Naar du koerer " + tal + " km, er fradraget " + fradrag + " og prisen efter skat er " + pris);
            }
        }//For-løkke slut
    }//Main metode slut
}//Klasse slut
