package lektion9;

import java.util.Scanner;

public class Lektion9 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        int valg = scanner.nextInt();

        if (valg == 1){
        Opgave1.HelloThere();
        }
    }
}
