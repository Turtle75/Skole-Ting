package lektion8;

import java.util.Scanner;

public class Lektion8 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("For at vise eksempel 4 fra lektionssaettet, tast 1 og ENTER, tryk paa 2 for at vise opgave 1");

        int tal = scanner.nextInt();

        if (tal == 1){
            Program1.HelloThere();
        }
        else if (tal==2){
            Opgave1.HelloThere();
        }
        else if (tal == 3){
            Opgave2.HelloThere();
        }
        else if ((tal == 4)){
            Program2.HelloThere();
        }
    }
}
