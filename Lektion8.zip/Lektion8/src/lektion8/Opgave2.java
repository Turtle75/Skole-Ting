package lektion8;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.util.Scanner;

public class Opgave2 {
    public static void HelloThere(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Indtast et aarstal, som der skal undersoeges om der er et skudaar");
        int aarstal = scanner.nextInt();
        boolean potentieltskudaar = aarstal % 4 == 0 && aarstal % 100 != 0;

        if (potentieltskudaar || aarstal % 400 == 0){
            System.out.println("Det er et skudaar");
            System.exit(1);
        }
        System.out.println("Det er ikke et skudaar");
    }
}