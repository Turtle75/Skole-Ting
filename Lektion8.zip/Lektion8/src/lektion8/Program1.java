package lektion8;

public class Program1 {
    public static void HelloThere(){
        int antalPrimtal = 0;

        for (int tal = 10; tal < 20; tal++){
            if (erPrimtal(tal)) antalPrimtal ++;
        }
        System.out.println("Antal primtal i alt: " +antalPrimtal);
    }

    public static boolean erPrimtal(int talUndersoeg){
        int faktor = 2;
        while (talUndersoeg % faktor > 0)
            faktor++;

        if (faktor < talUndersoeg){
            System.out.println(talUndersoeg + " har fakoren " + faktor);
            return false;
        }
        else{
            System.out.println(talUndersoeg + " er et primtal");
            return true;
        }
    }
}