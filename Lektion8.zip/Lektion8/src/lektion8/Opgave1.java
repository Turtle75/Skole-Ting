package lektion8;

import java.util.Scanner;

public class Opgave1 {
        public static void HelloThere(){
            int antalPrimtal = 0;

            //Laver 1 scanner (Scanner kan godt bruges flere gange)
            Scanner scanner = new Scanner(System.in);

            System.out.println("Indtast et interval der skal undersoeges fra primtal adskilt med mellemrum");
            //Scanner de 2 tal brugeren indtaster
            int tal1 = scanner.nextInt();
            int tal2 = scanner.nextInt();

            //Laver en while-løkke, hvor jeg siger at hvis det første tal -1 er mindre end tal2, så skal den eksekvere koden.
            while (tal1-1 < tal2){
                //Hvis metoden erPrimtal er true, så bliver værdien af antalPrimtal 1 højere
                if (erPrimtal(tal1)) antalPrimtal ++;
                //Bagefter går tal1 en op
                tal1++;
            }//While-løkke slut

            //Tæller op til sidst
            System.out.println("Antal primtal i alt: " +antalPrimtal);

        }

        public static boolean erPrimtal(int talUndersoeg){
            int faktor = 2;
            while (talUndersoeg % faktor > 0)
                faktor++;

            if (faktor < talUndersoeg){
                System.out.println(talUndersoeg + " har fakoren " + faktor);
                return false;
            }
            else{
                System.out.println(talUndersoeg + " er et primtal");
                return true;
            }
        }
}
