package lektion8;

import java.util.Scanner;

public class Program2 {
    public static void HelloThere()
    {
        int tal;
        int faktor = 2;
        System.out.print("\n\nIndtast et tal, der skal undersoeges(primtal): ");
        Scanner scanner = new Scanner(System.in);
        tal = scanner.nextInt();
        //loop, der søger efter faktorer: 2,3,4,…
        while (tal %faktor>0)
            faktor = faktor + 1;

        if (faktor < tal) // Der er fundet en faktor
        {
            System.out.println(tal+" er IKKE et primtal,");
            System.out.println("for det har faktoren "+faktor);
        }
        else
            System.out.println(tal +" er et primtal.");
    }

}
