package miniProjekt;

public class Punkt {
    private double x;
    private double y;
    public Punkt(double startx, double starty){
        x = startx;
        y = starty;
    }

    public double getX(){ return x; }
    public double getY(){ return y; }

    public double afstand (Punkt otherPt){
        double dx = x - otherPt.getX();
        double dy = y- otherPt.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }
}