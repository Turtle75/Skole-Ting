package miniProjekt;

import java.util.ArrayList;
import java.util.Scanner;

public class PolygonBeregner {
    public static void main(String[] args){
        double omkreds = 0, afstand1_2, afstandn_nn, a_n = 0, j = 0;
        int i = 1, antalKanter, brugerValg;
        String punkterListe = "";

        Scanner scanner = new Scanner(System.in);
        System.out.println("Angiv antallet af punkter i dit polygon");

        do {
            j++;
            if (j >= 2)
                System.out.println("Man kan ikke have mindre end 3 punkter, eller have flere end 20");
            antalKanter = scanner.nextInt();
        }
        while (antalKanter < 3 || antalKanter > 20);

        ArrayList<Double> punkter = new ArrayList<>();

        System.out.println("Skriv koordinaterne paa punkt 1");
        double x1 = scanner.nextDouble();
        double y1 = scanner.nextDouble();

        Punkt punkt1 = new Punkt(x1,y1);

        punkter.add(x1);
        punkter.add(y1);
        punkterListe = punkterListe + "(" + x1 + "; " + y1 + ")";
        for (int n = 1;i < antalKanter;n = n + 2){
            i++;
            System.out.println("\nSkriv koordinaterne paa punkt " + (i));
            double xn = scanner.nextDouble();
            double yn = scanner.nextDouble();

            punkter.add(xn);
            punkter.add(yn);

            punkterListe = punkterListe + "\n" + "(" + xn + "; " + yn + ")";

            if (n == 1){
                Punkt punkt2 = new Punkt(xn,yn);
                afstand1_2 = punkt1.afstand(punkt2);
                omkreds = afstand1_2;
            }
            else if (n > 1){
                Punkt punktFoer = new Punkt(punkter.get(n-1), punkter.get(n));
                Punkt punktEfter = new Punkt(punkter.get(n+1), punkter.get(n+2));
                afstandn_nn = punktFoer.afstand(punktEfter);

                omkreds = omkreds + afstandn_nn;

                if (i == antalKanter){
                    a_n = punkt1.afstand(punktEfter);
                    break;
                }
            }
        }
        omkreds = omkreds + a_n;
        do {
            System.out.println("\nSkriv 1 hvis du vil se omkredsen af polygonen, tryk 2 hvis du vil se punkterne, tryk 3 hvis du vil se begge dele, ellers skriv et andet tal");
            brugerValg = scanner.nextInt();
            if (brugerValg == 1){
                System.out.println("Omkredsen er i alt: " + omkreds);
            }
            else if (brugerValg == 2){
                System.out.println(punkterListe);
            }
            else if (brugerValg == 3){
                System.out.println("Omkredsen er i alt: " + omkreds);
                System.out.println("\nPunkterne er: " + punkterListe);
            }
        }
        while (brugerValg >= 1 && brugerValg <= 3);
        System.exit(1);
    }
}