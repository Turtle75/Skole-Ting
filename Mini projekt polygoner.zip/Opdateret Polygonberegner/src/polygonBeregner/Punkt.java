package polygonBeregner;

public class Punkt {
    //Variablerne erklæres
    private double x;
    private double y;

    //Laver et Punkt-objekt til at holde på koordinaterne af punkterne indtastet fra main-metoden
    public Punkt(double startx, double starty){
        x = startx;
        y = starty;
    }

    //Bruges til at returnerer x
    public double getX(){ return x; }
    public double getY(){ return y; }

    //Bruges til at beregne afstanden imellem 2 punkter
    public double afstand (Punkt otherPt){
        double dx = x - otherPt.getX();
        double dy = y- otherPt.getY();

        //Returnerer afstanden imellem punkterne
        return Math.sqrt(dx * dx + dy * dy);
    }
}