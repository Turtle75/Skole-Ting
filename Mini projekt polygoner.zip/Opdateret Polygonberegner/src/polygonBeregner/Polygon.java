package polygonBeregner;

import java.util.ArrayList;
import java.util.Scanner;

public class Polygon {
    public static void main(String[] args){
        //variablerne erklæres
        double omkreds = 0, afstand1_2, afstandn_nn, a_n = 0, j = 0, afstand1_sidste;
        int i = 0, h = 0, antalKanter, brugerValg;
        String punkterListe = "";

        //Initialiserer en scanner til at indlæse tekstinput fra brugeren
        Scanner scanner = new Scanner(System.in);

        //Bruges til at brugeren kan vælge en værdi inden for et interval mellem 3 og 20
        System.out.println("Angiv antallet af punkter i dit polygon");
        do {
            j++;
            if (j >= 2)
                System.out.println("Man kan ikke have mindre end 3 punkter, eller have flere end 20");
            antalKanter = scanner.nextInt();
        }
        while (antalKanter < 3 || antalKanter > 20);

        //Initierer en arrayliste til at holde på punkt-objekter
        ArrayList<Punkt> punkter = new ArrayList<Punkt>();

        //Laver en for-løkke til at indlæse de indtastede punkter fra brugeren, samt tilføjer punkterne på arraylisten
        for (int n = 1;i < antalKanter;n = n + 2){
            i++;
            System.out.println("\nSkriv koordinaterne paa punkt " + (i));
            double xn;
            double yn;

            //Opretter et punkt-objekt, ud fra brugerens indtastede x og y-værdier
            Punkt punkt = new Punkt(xn = scanner.nextDouble(), yn = scanner.nextDouble());

            //Tilføjer punktet til arraylisten
            punkter.add(punkt);

            //Bruges til senere at printe en liste af punkterne ud
            punkterListe = punkterListe + "\n" + "(" + xn + "; " + yn + ")";
        }//Første for-løkke slut

        //For-løkken her bruges til at beregne afstanden imellem punkterne
        for (int n = 0;n < (punkter.size()-1);n++){
            h++;

            afstandn_nn = punkter.get(n).afstand(punkter.get(n+1));

            //Tilføjer længden af afstanden imellem de to indtastede punkter til omkredsen, før for-løkken køres igen
            omkreds = omkreds + afstandn_nn;
        }
        //Beregner afstanden fra det første til det sidste punkt
        afstand1_sidste = punkter.get(0).afstand(punkter.get(h));
        omkreds = omkreds + afstand1_sidste;

        //Hvis brugeren indtaster nogle bestemte int-værdier vil den printe forskellige ting ud, ellers vil programmet lukke
        do {
            System.out.println("\nSkriv 1 hvis du vil se omkredsen af polygonen, tryk 2 hvis du vil se punkterne, tryk 3 hvis du vil se begge dele, ellers skriv et andet tal");

            //Scanner det brugeren indtaster
            brugerValg = scanner.nextInt();
            if (brugerValg == 1){
                System.out.println("Omkredsen er i alt: " + omkreds);
            }
            else if (brugerValg == 2){
                System.out.println(punkterListe);
            }
            else if (brugerValg == 3){
                System.out.println("Omkredsen er i alt: " + omkreds);
                System.out.println("\nPunkterne er: " + punkterListe);
            }
        }
        while (brugerValg >= 1 && brugerValg <= 3);
        System.exit(1);
    }
}